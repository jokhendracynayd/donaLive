module.exports = {
  // database: "mongodb://127.0.0.1:27017/dona_live",
  // database:"mongodb://donaAdmin:cynayd2022@13.234.16.85:27017/dona_live?authSource=admin",
    database:  "mongodb://donaAdmin:cynayd2022@3.7.87.3:27017/dona_live?authSource=admin",
  secret: 'coco'
}
