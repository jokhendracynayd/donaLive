let user={firstname:"jokhendra",lastname:"prajapati",collage:"millennium"};
// console.log(user);

for(let e in user){
  console.log(user[e]);
}